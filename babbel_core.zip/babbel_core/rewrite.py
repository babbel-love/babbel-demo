from __future__ import annotations
import re

HEDGES = [
    r"\bjust\b", r"\bmaybe\b", r"\bperhaps\b", r"\ba bit\b", r"\bsort of\b",
    r"\bkinda\b", r"\bprobably\b", r"\bI think\b", r"\bI guess\b",
]
FILLERS = [r"\bhonestly\b", r"\bliterally\b", r"\bto be honest\b", r"\bIMHO\b"]

def _strip_hedges(text: str) -> str:
    out = text
    for pat in HEDGES + FILLERS:
        out = re.sub(pat, "", out, flags=re.IGNORECASE)
    out = re.sub(r"\s{2,}", " ", out).strip()
    return out

def _tighten(text: str) -> str:
    # Collapse long rambles. Keep short, active, specific sentences.
    sents = re.split(r"(?<=[.!?])\s+", text.strip())
    sents = [s.strip() for s in sents if s.strip()]
    # Keep first 4 concise sentences max.
    out = []
    for s in sents:
        s = re.sub(r"\s+", " ", s)
        if len(s) > 280:
            s = s[:260].rstrip() + "…"
        out.append(s)
        if len(out) >= 4:
            break
    return " ".join(out)

def rewrite_tone(text: str) -> str:
    """Make language direct, concrete, no hedges/fillers."""
    if not text:
        return ""
    t = _strip_hedges(text)
    t = _tighten(t)
    return t

def enforce_babbel_style(text: str) -> str:
    """Deterministic Babbel style: concise, imperative hints, no fluff."""
    if not text:
        return ""
    t = rewrite_tone(text)
    # Ensure clear, confident ending (no trailing hedges).
    t = re.sub(r"(?:\.\s*)+$", ".", t.strip())
    return t
