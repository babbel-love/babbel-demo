from babbel_core.pipeline import run_pipeline

def test_pipeline_response():
    result = run_pipeline("I feel stuck.")
    assert "let’s take one small" in result.lower()
