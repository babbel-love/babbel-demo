import json
import os

class NodeRewriterV2:
    def __init__(self, rewrite_rules_file='babbel_core/node_response_rules.json'):
        self.rewrite_rules_file = rewrite_rules_file
        self.load_rewrite_rules()

    def load_rewrite_rules(self):
        with open(self.rewrite_rules_file, 'r') as file:
            self.rewrite_rules = json.load(file)
        print("🔍 DEBUG: rules =", self.rewrite_rules)

    def rewrite_node(self, message: str) -> str:
        for rule in self.rewrite_rules:
            if rule['trigger'].lower() in message.lower():
                return rule['response']
        return message

# === Top-level helper for engine.py ===
rewriter = NodeRewriterV2()

def run_node_rewrite(text: str) -> str:
    return rewriter.rewrite_node(text)
