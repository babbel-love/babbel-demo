# Babbel (Streamlit Edition)
Fully local, deterministic conversation engine with tone, emotion, and protocol enforcement. No GPT fallback. No external APIs.
