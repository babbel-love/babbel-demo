from babbel_core.node_rules import apply_node_rules

def test_node_rule_output():
    result = apply_node_rules("I'm overwhelmed", "sadness", "seek guidance")
    assert isinstance(result, str)
