import json
import os, requests
import streamlit as st
from .memory_tracker import log_interaction, get_recent_emotions
from .rewrite import rewrite_tone, enforce_babbel_style

SPEECH = {
    "greeting": "Hi—how can I help?",
    "farewell": "Take care. If anything changes, come back and we’ll adjust.",
    "help": "Sure—what do you need?",
    "thanks": "You’re welcome.",
}

def babbelize(txt: str) -> str:
    try:
        return enforce_babbel_style(rewrite_tone(txt)).strip()
    except Exception:
        return txt

def quick_protocol(msg: str):
    t = msg.lower().strip()
    if any(x in t for x in ("hi", "hello", "hey")) and "greeting" in SPEECH:
        return SPEECH["greeting"]
    if "help" in t and "help" in SPEECH:
        return SPEECH["help"]
    if "thanks" in t and "thank" in t and "thanks" in SPEECH:
        return SPEECH["thanks"]
    if any(x in t for x in ("bye", "goodbye", "later")) and "farewell" in SPEECH:
        return SPEECH["farewell"]
    return None

HARD_CODED_API_KEY = os.getenv("OPENROUTER_API_KEY","")
OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"
SYSTEM_PROMPT = (
    "You are Babbel. Respond concisely, concretely, and without filler. "
    "Be direct, specific, and pragmatic. Avoid hedges like 'maybe'/'just'. "
    "When helpful, provide short steps or a crisp summary. "
    "If the user asks for recent facts, be explicit about uncertainty."
)

def call_openrouter(messages):
    headers = {
        "Authorization": f"Bearer {HARD_CODED_API_KEY}",
        "Content-Type": "application/json",
        "X-Title": "Babbel Core (Streamlit)",
        "HTTP-Referer": "http://localhost:8501/",
    }
    payload = {
        "model": "openrouter/auto",
        "messages": messages,
        "temperature": 0.3,
    }
    resp = requests.post(OPENROUTER_URL, headers=headers, json=payload, timeout=90)
    if resp.status_code >= 400:
        raise RuntimeError(f"OpenRouter error {resp.status_code}: {resp.text}")
    data = resp.json()
    return data["choices"][0]["message"]["content"]

# === Streamlit UI ===
st.set_page_config(page_title="Babbel Core — Streamlit", layout="centered")
st.title("🧠 Babbel Core — Streamlit App")
st.sidebar.header("🧭 Emotional Trajectory")
recent = get_recent_emotions(10)
st.sidebar.write(", ".join(recent[-10:]) if recent else "No history yet — start chatting below.")

if "messages" not in st.session_state:
    st.session_state.messages = []

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

prompt = st.chat_input("Type your message…")

if prompt:
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    quick = quick_protocol(prompt)
    if quick:
        assistant_text = quick
    else:
        messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        messages += st.session_state.messages[-20:]
        try:
            llm = call_openrouter(messages)
            assistant_text = babbelize(llm)
        except Exception as e:
            assistant_text = f"⚠️ Error: {e}"

    st.session_state.messages.append({"role": "assistant", "content": assistant_text})
    with st.chat_message("assistant"):
        st.markdown(assistant_text)
    try:
        log_interaction(prompt, "n/a", "n/a", "openrouter", assistant_text)
    except:
        pass
