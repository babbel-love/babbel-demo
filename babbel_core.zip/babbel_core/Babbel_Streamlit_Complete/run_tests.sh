#!/bin/bash
pytest tests/ --tb=short -q
