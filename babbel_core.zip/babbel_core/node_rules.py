from __future__ import annotations

RESPONSES = {
    ("shame","seek guidance"): "We’ll take this step by step. You’re not broken; we’ll target one small, doable action.",
    ("grief","search for meaning"): "Name the loss, then one thing you want to honor. We’ll keep it gentle and specific.",
    ("anger","general"): "Let’s separate facts, interpretations, and asks. Pick one concrete request you can make.",
    ("fear","seek guidance"): "We’ll reduce uncertainty: identify the smallest safe experiment you can run today.",
    ("wonder","general"): "Follow the spark. Choose one question worth answering with a tiny prototype.",
}

def apply_node_rules(text: str, emotion: str, intent: str) -> str:
    key = (emotion or "mixed", intent or "general")
    return RESPONSES.get(key, "We’ll slow this down and choose one clear next step you can take.")
