from __future__ import annotations

def classify_emotion(text: str) -> str:
    t = (text or "").lower()
    if any(w in t for w in ["ashamed","worthless","disgust","embarrass"]): return "shame"
    if any(w in t for w in ["sad","loss","heartbroken","grief","cry"]):   return "grief"
    if any(w in t for w in ["angry","furious","rage","annoy","irritat"]): return "anger"
    if any(w in t for w in ["scared","anxious","afraid","nervous"]):      return "fear"
    if any(w in t for w in ["wonder","curious","awe","inspired"]):        return "wonder"
    if any(w in t for w in ["joy","glad","happy","excited","relief"]):    return "joy"
    return "mixed"
