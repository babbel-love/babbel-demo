from babbel_core.emotion_classifier import classify_emotion

def test_emotion_classify():
    assert classify_emotion("I'm scared.") == "fear"
