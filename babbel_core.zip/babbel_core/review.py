from __future__ import annotations
import re

PROFANITY = ["fuck","shit","bitch","asshole","bastard"]

def _mask_profanity(t: str) -> str:
    out = t
    for w in PROFANITY:
        out = re.sub(rf"(?i)\b{re.escape(w)}\b", w[0] + "★"*(len(w)-1), out)
    return out

def run_review_stage(text: str) -> str:
    if not text: return ""
    t = text.strip()
    t = _mask_profanity(t)
    # Clip ultra-long outputs
    if len(t) > 2000: t = t[:1990].rstrip() + "…"
    return t
