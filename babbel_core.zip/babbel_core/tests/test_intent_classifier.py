from babbel_core.intent_classifier import classify_intent

def test_intent_classify():
    assert classify_intent("Can you help me?") == "seek guidance"
