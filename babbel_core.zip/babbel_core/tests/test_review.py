from babbel_core.review import run_review_stage

def test_review_response():
    result = run_review_stage("This might help.")
    assert isinstance(result, str)
