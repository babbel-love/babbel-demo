from __future__ import annotations

def classify_intent(text: str) -> str:
    t = (text or "").lower()
    if any(w in t for w in ["what should","how do i","need advice","help me","guide me"]): return "seek guidance"
    if any(w in t for w in ["i'm sorry","its my fault","it's my fault","apologize","confess"]): return "confession"
    if any(w in t for w in ["why did","what does it mean","meaning of","make sense of"]): return "search for meaning"
    if any(w in t for w in ["translate","in spanish","in french","in japanese"]): return "translate"
    if any(w in t for w in ["summarize","tl;dr","short version"]): return "summarize"
    return "general"
