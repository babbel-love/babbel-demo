#!/bin/bash
echo "🧹 Deleting duplicate review.py in root..."

rm -v ./review.py

echo "✅ Done. Only core/review.py remains."
